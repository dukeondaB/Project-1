<div class="container">
      <div class="row align-items-start">
        <div class="col">
          <img src="../assets/img/logo-mb.png" width="70%" alt="">
          <h5><a href="">Giới thiệu về công ty</a></h5>
          <h5><a href="">Câu hỏi thường gặp khi mua hàng</a></h5>
          <h5><a href="">Chính sách bảo mật</a></h5>
          <h5><a href="">Quy chế hoạt động</a></h5>
        </div>
        <div class="col" id="col5">
          <h4>Thông tin liên hệ</h4>
          <h5><a href="">Tư vấn mua hàng</a></h5>
          <h5><a href="">1800 6601 (Nhánh 1)</a></h5>
          <h5><a href="">Hỗ trợ kỹ thuật</a></h5>
          <h5><a href="">1800 6601 (Nhánh 2)</a></h5>
        </div>
        <div class="col" id="col6">
          <h4>Chính sách hỗ trợ</h4>
          <h5><a href="">Chính sách giao hàng</a></h5>
          <h5><a href="">Chính sách đổi trả hàng</a></h5>
          <h5><a href="">Hướng dẫn thanh toán</a></h5>
          <h5><a href="">Hướng dẫn mua hàng</a></h5>
        </div>
      </div>
    </div>