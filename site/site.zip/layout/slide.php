<div class="container" id="carousel">
<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="../assets/img/637720541178079234_F-H1_800x300.jfif" class="d-block w-100" alt="...">
          </div>
          <div class="carousel-item">
            <img src="../assets/img/637698229744956243_F-H1_800x300.jfif" class="d-block w-100" alt="...">
          </div>
          <div class="carousel-item">
            <img src="../assets/img/637720541178079234_F-H1_800x300.jfif" class="d-block w-100" alt="...">
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
          data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
          data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
      </div>