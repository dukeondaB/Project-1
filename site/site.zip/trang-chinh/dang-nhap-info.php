        </div>
        <div class="container">
      <div class="row align-items-start">
        <div class="col">
          <a href="trang-chu.html"><img src="../assets/img/logo-mb.png" width="70%" alt=""></a>
        </div>
        <div class="col">
          <div class="input-group rounded" id="input">

            <i class="fas fa-search" id="icon-search"></i>

            <input type="search" class="form-control rounded" id="search" placeholder="Tìm kiếm sản phẩm"
              aria-label="Search" aria-describedby="search-addon" />

          </div>
        </div>
        <div class="col" id="col3">
          <a href="gio-hang.html"><button id="btn-cart"><img src="../assets/img/trolley-cart 1.png" alt=""></button></a>
          <?= $_SESSION['user']['ho_va_ten']?>
          <a id="dn" href="../tai-khoan/dang-nhap.php?btn_logoff">Đăng xuất</a>
        </div>
      </div>
    </div>